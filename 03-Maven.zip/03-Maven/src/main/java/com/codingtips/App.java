package com.codingtips;

import java.net.MalformedURLException;

import com.learn.EncodeDecode;

public class App {
public static void main(String[] args) {
	EncodeDecode en=new EncodeDecode();
	String encodeString=en.encode("manonmani");
	System.out.println("Encoding String "+encodeString);
	String decode=en.decode(encodeString);
	System.out.println(decode);
}
}
