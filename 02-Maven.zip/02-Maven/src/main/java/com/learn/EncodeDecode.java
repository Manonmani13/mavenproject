package com.learn;

import java.util.Base64.Decoder;
import java.util.Base64.Encoder;
import java.util.Base64;

public class EncodeDecode {
public String encode(String  text)
{
	Encoder encoder=Base64.getEncoder();
	byte[] encode=encoder.encode(text.getBytes());
	return new String(encode);
			
}
public String decode(String encodedText)
{
	Decoder decoder=Base64.getDecoder();
	byte[] decode=decoder.decode(encodedText);
	return new String(decode);
}
}
