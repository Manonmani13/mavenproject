package com.ashok.it;

public class Calculator {

	public Integer add(int no1,int no2)
	{
		int result=no1+no2;
		return result;
	}
}
